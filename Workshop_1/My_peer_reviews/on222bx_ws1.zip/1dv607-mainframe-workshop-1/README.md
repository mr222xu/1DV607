# Mainframe

## Workshop 1


### Gruppmedlemmar

• Axel Karlsson - ak223fy@student.lnu.se

• Loke Carlsson - lc222ak@student.lnu.se

• Oscar Nordquist - on222bx@student.lnu.se

